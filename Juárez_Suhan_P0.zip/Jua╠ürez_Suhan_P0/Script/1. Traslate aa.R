####################################
###### 1. Con librerias especializadas buscar la secuencia de aminoácidos####
####################################

#A partir de una secuencia dada aplicar secuencia complementaria
#primero abrimos la libreria para abrir el archivo correspondiente
library(Biostrings)

#SECCIÓN 1####

#Después abrimos un archivo de secuencias concatenadas de RNA (que se nos dieron)
Secuencias1<-readRNAStringSet("Raw Data/first (1).fasta")
Secuencias1 #Podemos visualizarla, tenemos 5, muy cortas. 

#SECCIÓN 2####
AminoacidSeq1<-translate(Secuencias1)
AminoacidSeq1










