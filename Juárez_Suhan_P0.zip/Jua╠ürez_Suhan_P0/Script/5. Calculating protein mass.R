####################################
###### 5. Calculating Protein Mass  ####
####################################
#Calcular la masa de una proteína a partir de la suma de pesos de todos los aminoácidos que la componen

#Primero pasaremos de ARN a proteína (aa) cada proteína

######NOTA####

###DEBE EJECUTARSE SECCIÓN 1 DEL EJERCICIO 1 y SECCIÓN 1 DEL EJERCICIO 2 PARA CONTINUAR CON ESTE EJERCICIO

####################################################

#SECCIÓN 1####
#En esta parte, lo que debemos hacer es crear vectores que contengan la secuencia de los codones

F1<-c("U","U","U")
F2<-c("U","U","C")
L1<-c("U","U","A")
L2<-c("U","U","G")
L3<-c("C","U","U")
L4<-c("C","U","C")
L5<-c("C","U","A")
L6<-c("C","U","G")
I1<-c("A","U","U")
I2<-c("A","U","C")
I3<-c("A","U","A")
M1<-c("A","U","G")
V1<-c("G","U","U")
V2<-c("G","C","C")
V3<-c("G","U","A")
V4<-c("G","U","G")
S1<-c("U","C","U")
S2<-c("G","U","C")
S3<-c("U","C","A")
S4<-c("U","C","G")
P1<-c("C","C","U")
P2<-c("C","C","C")
P3<-c("C","C","A")
P4<-c("C","C","G")
T1<-c("A","C","U")
T2<-c("A","C","C")
T3<-c("A","C","A")
T4<-c("A","C","G")
A1<-c("G","C","U")
A2<-c("G","C","C")
A3<-c("G","C","A")
A4<-c("G","C","G")
Y1<-c("U","A","U")
Y2<-c("U","A","C")
STOP1<-c("U","A","A")
STOP2<-c("U","A","G")
STOP3<-c("U","G","A")
H1<-c("C","A","U")
H2<-c("C","A","C")
Q1<-c("C","A","A")
Q2<-c("C","A","G")
N1<-c("A","A","U")
N2<-c("A","A","C")
K1<-c("A","A","A")
K2<-c("A","A","G")
D1<-c("G","A","U")
D2<-c("G","A","C")
E1<-c("G","A","A")
E2<-c("G","A","G")
C1<-c("U","G","U")
C2<-c("U","A","C")
W1<-c("U","G","G")
R1<-c("C","G","U")
R2<-c("C","G","C")
R3<-c("C","G","A")
R4<-c("C","G","G")
R5<-c("A","G","A")
R6<-c("A","G","G")
S1<-c("A","G","U")
S2<-c("A","G","C")
G1<-c("G","G","U")
G2<-c("G","G","C")
G3<-c("G","G","A")
G4<-c("G","G","G")

##En este mismo programa, agregamos una tabla de las masas de cada aminoácido (Obtenido de Rosalind)
aaA<-71.03711
aaC<-103.00919
aaD<-115.02694
aaE<-129.04259
aaF<-147.06841
aaG<-57.02146
aaH<-137.05891
aaI<-113.08406
aaK<-128.09496
aaL<-113.08406
aaM<-131.04049
aaN<-114.04293
aaP<-97.05276
aaQ<-128.05858
aaR<-156.10111
aaS<-87.03203
aaT<-101.04768
aaV<-99.06841
aaW<-186.07931
aaY<-163.06333
aaSTOP<-0

#SECCIÓN 2####
#en este punto fragmentamos la secuencia para que se reemplace el codón por el aminoácido
Frag_Seq0<-split(Seq0, ceiling(seq_along(Seq0)/3))

#Empleamos el siguiente programa para sustituir aa
Prot0<-c()
Mass0<-0
for (codon in Frag_Seq0) {
  
  if (all(codon == F1) | all(codon == F2)) {
    Prot0<-c(Prot0, "F")
    Mass0<-Mass0 + aaF
  } else if (all(codon == L1) | all(codon == L2) | all(codon == L3) | all(codon == L4) | all(codon == L5) | all(codon == L6)) {
    Prot0<-c(Prot0, "L")
    Mass0<-Mass0 + aaL
  } else if (all(codon == I1) | all(codon == I2) | all(codon == I3)) {
    Prot0<-c(Prot0, "I") 
    Mass0<-Mass0 + aaI
  } else if (all(codon == M1)) {
    Prot0<-c(Prot0, "M")
    Mass0<-Mass0 + aaM
  } else if (all(codon == V1) | all(codon == V2) | all(codon == V3) | all(codon == V4)) {
    Prot0<-c(Prot0, "V")
    Mass0<-Mass0 + aaV
  } else if (all(codon == S1) | all(codon == S2) | all(codon == S3) | all(codon == S4)) {
    Prot0<-c(Prot0, "S")
    Mass0<-Mass0 + aaS
  } else if (all(codon == P1) | all(codon == P2) | all(codon == P3) | all(codon == P4)) {
    Prot0<-c(Prot0, "P")
    Mass0<-Mass0 + aaP
  } else if (all(codon == T1) | all(codon == T2) | all(codon == T3) | all(codon == T4)) {
    Prot0<-c(Prot0, "T")
    Mass0<-Mass0 + aaT
  } else if (all(codon == A1) | all(codon == A2) | all(codon == A3) | all(codon == A4)) {
    Prot0<-c(Prot0, "A")
    Mass0<-Mass0 + aaA
  } else if (all(codon == Y1) | all(codon == Y2)) {
    Prot0<-c(Prot0, "Y")
    Mass0<-Mass0 + aaY
  } else if (all(codon == STOP1) | all(codon == STOP2) | all(codon == STOP3)) {
    Prot0<-c(Prot0, "STOP")
    Mass0<-Mass0 + aaSTOP
  } else if (all(codon == H1) | all(codon == H2)) {
    Prot0<-c(Prot0, "H")
    Mass0<-Mass0 + aaH
  } else if (all(codon == Q1) | all(codon == Q2)) {
    Prot0<-c(Prot0, "Q")
    Mass0<-Mass0 + aaQ
  } else if (all(codon == N1) | all(codon == N2)) {
    Prot0<-c(Prot0, "N")
    Mass0<-Mass0 + aaN
  } else if (all(codon == K1) | all(codon == K2)) {
    Prot0<-c(Prot0, "K")
    Mass0<-Mass0 + aaK
  } else if (all(codon == D1) | all(codon == D2)) {
    Prot0<-c(Prot0, "D")
    Mass0<-Mass0 + aaD
  } else if (all(codon == E1) | all(codon == E2)) {
    Prot0<-c(Prot0, "E")
    Mass0<-Mass0 + aaE
  } else if (all(codon == C1) | all(codon == C2)) {
    Prot0<-c(Prot0, "C")
    Mass0<-Mass0 + aaC
  } else if (all(codon == W1)) {
    Prot0<-c(Prot0, "W")
    Mass0<-Mass0 + aaW
  } else if (all(codon == R1) | all(codon == R2) | all(codon == R3) | all(codon == R4) | all(codon == R5) | all(codon == R6)) {
    Prot0<-c(Prot0, "R")
    Mass0<-Mass0 + aaR
  } else if (all(codon == S1) | all(codon == S2)) {
    Prot0<-c(Prot0, "S")
    Mass0<-Mass0 + aaS
  } else if (all(codon == G1) | all(codon == G2) | all(codon == G3) | all(codon == G4)) {
    Prot0<-c(Prot0, "G")
    Mass0<-Mass0 + aaG
  } else {
    Prot0<-c(Prot0, codon)
  }
  
}

Prot0
Mass0


#Para la segunda proteína
Frag_Seq1<-split(Seq1, ceiling(seq_along(Seq1)/3))


Prot1<-c()
Mass1<-0
for (codon in Frag_Seq1) {
  
  if (all(codon == F1) | all(codon == F2)) {
    Prot1<-c(Prot1, "F")
    Mass1<-Mass1 + aaF
  } else if (all(codon == L1) | all(codon == L2) | all(codon == L3) | all(codon == L4) | all(codon == L5) | all(codon == L6)) {
    Prot1<-c(Prot1, "L")
    Mass1<-Mass1 + aaL
  } else if (all(codon == I1) | all(codon == I2) | all(codon == I3)) {
    Prot1<-c(Prot1, "I") 
    Mass1<-Mass1 + aaI
  } else if (all(codon == M1)) {
    Prot1<-c(Prot1, "M")
    Mass1<-Mass1 + aaM
  } else if (all(codon == V1) | all(codon == V2) | all(codon == V3) | all(codon == V4)) {
    Prot1<-c(Prot1, "V")
    Mass1<-Mass1 + aaV
  } else if (all(codon == S1) | all(codon == S2) | all(codon == S3) | all(codon == S4)) {
    Prot1<-c(Prot1, "S")
    Mass1<-Mass1 + aaS
  } else if (all(codon == P1) | all(codon == P2) | all(codon == P3) | all(codon == P4)) {
    Prot1<-c(Prot1, "P")
    Mass1<-Mass1 + aaP
  } else if (all(codon == T1) | all(codon == T2) | all(codon == T3) | all(codon == T4)) {
    Prot1<-c(Prot1, "T")
    Mass1<-Mass1 + aaT
  } else if (all(codon == A1) | all(codon == A2) | all(codon == A3) | all(codon == A4)) {
    Prot1<-c(Prot1, "A")
    Mass1<-Mass1 + aaA
  } else if (all(codon == Y1) | all(codon == Y2)) {
    Prot1<-c(Prot1, "Y")
    Mass1<-Mass1 + aaY
  } else if (all(codon == STOP1) | all(codon == STOP2) | all(codon == STOP3)) {
    Prot1<-c(Prot1, "STOP")
    Mass1<-Mass1 + aaSTOP
  } else if (all(codon == H1) | all(codon == H2)) {
    Prot1<-c(Prot1, "H")
    Mass1<-Mass1 + aaH
  } else if (all(codon == Q1) | all(codon == Q2)) {
    Prot1<-c(Prot1, "Q")
    Mass1<-Mass1 + aaQ
  } else if (all(codon == N1) | all(codon == N2)) {
    Prot1<-c(Prot1, "N")
    Mass1<-Mass1 + aaN
  } else if (all(codon == K1) | all(codon == K2)) {
    Prot1<-c(Prot1, "K")
    Mass1<-Mass1 + aaK
  } else if (all(codon == D1) | all(codon == D2)) {
    Prot1<-c(Prot1, "D")
    Mass1<-Mass1 + aaD
  } else if (all(codon == E1) | all(codon == E2)) {
    Prot1<-c(Prot1, "E")
    Mass1<-Mass1 + aaE
  } else if (all(codon == C1) | all(codon == C2)) {
    Prot1<-c(Prot1, "C")
    Mass1<-Mass1 + aaC
  } else if (all(codon == W1)) {
    Prot1<-c(Prot1, "W")
    Mass1<-Mass1 + aaW
  } else if (all(codon == R1) | all(codon == R2) | all(codon == R3) | all(codon == R4) | all(codon == R5) | all(codon == R6)) {
    Prot1<-c(Prot1, "R")
    Mass1<-Mass1 + aaR
  } else if (all(codon == S1) | all(codon == S2)) {
    Prot1<-c(Prot1, "S")
    Mass1<-Mass1 + aaS
  } else if (all(codon == G1) | all(codon == G2) | all(codon == G3) | all(codon == G4)) {
    Prot1<-c(Prot1, "G")
    Mass1<-Mass1 + aaG
  } else {
    Prot1<-c(Prot1, codon)
  }
  
}

Prot1
Mass1

#Para la tercera proteína
Frag_Seq2<-split(Seq2, ceiling(seq_along(Seq2)/3))


Prot2<-c()
Mass2<-0
for (codon in Frag_Seq2) {
  
  if (all(codon == F1) | all(codon == F2)) {
    Prot2<-c(Prot2, "F")
    Mass2<-Mass2 + aaF
  } else if (all(codon == L1) | all(codon == L2) | all(codon == L3) | all(codon == L4) | all(codon == L5) | all(codon == L6)) {
    Prot2<-c(Prot2, "L")
    Mass2<-Mass2 + aaL
  } else if (all(codon == I1) | all(codon == I2) | all(codon == I3)) {
    Prot2<-c(Prot2, "I") 
    Mass2<-Mass2 + aaI
  } else if (all(codon == M1)) {
    Prot2<-c(Prot2, "M")
    Mass2<-Mass2 + aaM
  } else if (all(codon == V1) | all(codon == V2) | all(codon == V3) | all(codon == V4)) {
    Prot2<-c(Prot2, "V")
    Mass2<-Mass2 + aaV
  } else if (all(codon == S1) | all(codon == S2) | all(codon == S3) | all(codon == S4)) {
    Prot2<-c(Prot2, "S")
    Mass2<-Mass2 + aaS
  } else if (all(codon == P1) | all(codon == P2) | all(codon == P3) | all(codon == P4)) {
    Prot2<-c(Prot2, "P")
    Mass2<-Mass2 + aaP
  } else if (all(codon == T1) | all(codon == T2) | all(codon == T3) | all(codon == T4)) {
    Prot2<-c(Prot2, "T")
    Mass2<-Mass2 + aaT
  } else if (all(codon == A1) | all(codon == A2) | all(codon == A3) | all(codon == A4)) {
    Prot2<-c(Prot2, "A")
    Mass2<-Mass2 + aaA
  } else if (all(codon == Y1) | all(codon == Y2)) {
    Prot2<-c(Prot2, "Y")
    Mass2<-Mass2 + aaY
  } else if (all(codon == STOP1) | all(codon == STOP2) | all(codon == STOP3)) {
    Prot2<-c(Prot2, "STOP")
    Mass2<-Mass2 + aaSTOP
  } else if (all(codon == H1) | all(codon == H2)) {
    Prot2<-c(Prot2, "H")
    Mass2<-Mass2 + aaH
  } else if (all(codon == Q1) | all(codon == Q2)) {
    Prot2<-c(Prot2, "Q")
    Mass2<-Mass2 + aaQ
  } else if (all(codon == N1) | all(codon == N2)) {
    Prot2<-c(Prot2, "N")
    Mass2<-Mass2 + aaN
  } else if (all(codon == K1) | all(codon == K2)) {
    Prot2<-c(Prot2, "K")
    Mass2<-Mass2 + aaK
  } else if (all(codon == D1) | all(codon == D2)) {
    Prot2<-c(Prot2, "D")
    Mass2<-Mass2 + aaD
  } else if (all(codon == E1) | all(codon == E2)) {
    Prot2<-c(Prot2, "E")
    Mass2<-Mass2 + aaE
  } else if (all(codon == C1) | all(codon == C2)) {
    Prot2<-c(Prot2, "C")
    Mass2<-Mass2 + aaC
  } else if (all(codon == W1)) {
    Prot2<-c(Prot2, "W")
    Mass2<-Mass2 + aaW
  } else if (all(codon == R1) | all(codon == R2) | all(codon == R3) | all(codon == R4) | all(codon == R5) | all(codon == R6)) {
    Prot2<-c(Prot2, "R")
    Mass2<-Mass2 + aaR
  } else if (all(codon == S1) | all(codon == S2)) {
    Prot2<-c(Prot2, "S")
    Mass2<-Mass2 + aaS
  } else if (all(codon == G1) | all(codon == G2) | all(codon == G3) | all(codon == G4)) {
    Prot2<-c(Prot2, "G")
    Mass2<-Mass2 + aaG
  } else {
    Prot2<-c(Prot2, codon)
  }
  
}

Prot2
Mass2

#Para la cuarta proteína
Frag_Seq3<-split(Seq3, ceiling(seq_along(Seq3)/3))


Prot3<-c()
Mass3<-0
for (codon in Frag_Seq3) {
  
  if (all(codon == F1) | all(codon == F2)) {
    Prot3<-c(Prot3, "F")
    Mass3<-Mass3 + aaF
  } else if (all(codon == L1) | all(codon == L2) | all(codon == L3) | all(codon == L4) | all(codon == L5) | all(codon == L6)) {
    Prot3<-c(Prot3, "L")
    Mass3<-Mass3 + aaL
  } else if (all(codon == I1) | all(codon == I2) | all(codon == I3)) {
    Prot3<-c(Prot3, "I") 
    Mass3<-Mass3 + aaI
  } else if (all(codon == M1)) {
    Prot3<-c(Prot3, "M")
    Mass3<-Mass3 + aaM
  } else if (all(codon == V1) | all(codon == V2) | all(codon == V3) | all(codon == V4)) {
    Prot3<-c(Prot3, "V")
    Mass3<-Mass3 + aaV
  } else if (all(codon == S1) | all(codon == S2) | all(codon == S3) | all(codon == S4)) {
    Prot3<-c(Prot3, "S")
    Mass3<-Mass3 + aaS
  } else if (all(codon == P1) | all(codon == P2) | all(codon == P3) | all(codon == P4)) {
    Prot3<-c(Prot3, "P")
    Mass3<-Mass3 + aaP
  } else if (all(codon == T1) | all(codon == T2) | all(codon == T3) | all(codon == T4)) {
    Prot3<-c(Prot3, "T")
    Mass3<-Mass3 + aaT
  } else if (all(codon == A1) | all(codon == A2) | all(codon == A3) | all(codon == A4)) {
    Prot3<-c(Prot3, "A")
    Mass3<-Mass3 + aaA
  } else if (all(codon == Y1) | all(codon == Y2)) {
    Prot3<-c(Prot3, "Y")
    Mass3<-Mass3 + aaY
  } else if (all(codon == STOP1) | all(codon == STOP2) | all(codon == STOP3)) {
    Prot3<-c(Prot3, "STOP")
    Mass3<-Mass3 + aaSTOP
  } else if (all(codon == H1) | all(codon == H2)) {
    Prot3<-c(Prot3, "H")
    Mass3<-Mass3 + aaH
  } else if (all(codon == Q1) | all(codon == Q2)) {
    Prot3<-c(Prot3, "Q")
    Mass3<-Mass3 + aaQ
  } else if (all(codon == N1) | all(codon == N2)) {
    Prot3<-c(Prot3, "N")
    Mass3<-Mass3 + aaN
  } else if (all(codon == K1) | all(codon == K2)) {
    Prot3<-c(Prot3, "K")
    Mass3<-Mass3 + aaK
  } else if (all(codon == D1) | all(codon == D2)) {
    Prot3<-c(Prot3, "D")
    Mass3<-Mass3 + aaD
  } else if (all(codon == E1) | all(codon == E2)) {
    Prot3<-c(Prot3, "E")
    Mass3<-Mass3 + aaE
  } else if (all(codon == C1) | all(codon == C2)) {
    Prot3<-c(Prot3, "C")
    Mass3<-Mass3 + aaC
  } else if (all(codon == W1)) {
    Prot3<-c(Prot3, "W")
    Mass3<-Mass3 + aaW
  } else if (all(codon == R1) | all(codon == R2) | all(codon == R3) | all(codon == R4) | all(codon == R5) | all(codon == R6)) {
    Prot3<-c(Prot3, "R")
    Mass3<-Mass3 + aaR
  } else if (all(codon == S1) | all(codon == S2)) {
    Prot3<-c(Prot3, "S")
    Mass3<-Mass3 + aaS
  } else if (all(codon == G1) | all(codon == G2) | all(codon == G3) | all(codon == G4)) {
    Prot3<-c(Prot3, "G")
    Mass3<-Mass3 + aaG
  } else {
    Prot3<-c(Prot3, codon)
  }
  
}

Prot3
Mass3


#Para la quinta proteína
Frag_Seq4<-split(Seq4, ceiling(seq_along(Seq4)/3))


Prot4<-c()
Mass4<-0
for (codon in Frag_Seq4) {
  
  if (all(codon == F1) | all(codon == F2)) {
    Prot4<-c(Prot4, "F")
    Mass4<-Mass4 + aaF
  } else if (all(codon == L1) | all(codon == L2) | all(codon == L3) | all(codon == L4) | all(codon == L5) | all(codon == L6)) {
    Prot4<-c(Prot4, "L")
    Mass4<-Mass4 + aaL
  } else if (all(codon == I1) | all(codon == I2) | all(codon == I3)) {
    Prot4<-c(Prot4, "I") 
    Mass4<-Mass4 + aaI
  } else if (all(codon == M1)) {
    Prot4<-c(Prot4, "M")
    Mass4<-Mass4 + aaM
  } else if (all(codon == V1) | all(codon == V2) | all(codon == V3) | all(codon == V4)) {
    Prot4<-c(Prot4, "V")
    Mass4<-Mass4 + aaV
  } else if (all(codon == S1) | all(codon == S2) | all(codon == S3) | all(codon == S4)) {
    Prot4<-c(Prot4, "S")
    Mass4<-Mass4 + aaS
  } else if (all(codon == P1) | all(codon == P2) | all(codon == P3) | all(codon == P4)) {
    Prot4<-c(Prot4, "P")
    Mass4<-Mass4 + aaP
  } else if (all(codon == T1) | all(codon == T2) | all(codon == T3) | all(codon == T4)) {
    Prot4<-c(Prot4, "T")
    Mass4<-Mass4 + aaT
  } else if (all(codon == A1) | all(codon == A2) | all(codon == A3) | all(codon == A4)) {
    Prot4<-c(Prot4, "A")
    Mass4<-Mass4 + aaA
  } else if (all(codon == Y1) | all(codon == Y2)) {
    Prot4<-c(Prot4, "Y")
    Mass4<-Mass4 + aaY
  } else if (all(codon == STOP1) | all(codon == STOP2) | all(codon == STOP3)) {
    Prot4<-c(Prot4, "STOP")
    Mass4<-Mass4 + aaSTOP
  } else if (all(codon == H1) | all(codon == H2)) {
    Prot4<-c(Prot4, "H")
    Mass4<-Mass4 + aaH
  } else if (all(codon == Q1) | all(codon == Q2)) {
    Prot4<-c(Prot4, "Q")
    Mass4<-Mass4 + aaQ
  } else if (all(codon == N1) | all(codon == N2)) {
    Prot4<-c(Prot4, "N")
    Mass4<-Mass4 + aaN
  } else if (all(codon == K1) | all(codon == K2)) {
    Prot4<-c(Prot4, "K")
    Mass4<-Mass4 + aaK
  } else if (all(codon == D1) | all(codon == D2)) {
    Prot4<-c(Prot4, "D")
    Mass4<-Mass4 + aaD
  } else if (all(codon == E1) | all(codon == E2)) {
    Prot4<-c(Prot4, "E")
    Mass4<-Mass4 + aaE
  } else if (all(codon == C1) | all(codon == C2)) {
    Prot4<-c(Prot4, "C")
    Mass4<-Mass4 + aaC
  } else if (all(codon == W1)) {
    Prot4<-c(Prot4, "W")
    Mass4<-Mass4 + aaW
  } else if (all(codon == R1) | all(codon == R2) | all(codon == R3) | all(codon == R4) | all(codon == R5) | all(codon == R6)) {
    Prot4<-c(Prot4, "R")
    Mass4<-Mass4 + aaR
  } else if (all(codon == S1) | all(codon == S2)) {
    Prot4<-c(Prot4, "S")
    Mass4<-Mass4 + aaS
  } else if (all(codon == G1) | all(codon == G2) | all(codon == G3) | all(codon == G4)) {
    Prot4<-c(Prot4, "G")
    Mass4<-Mass4 + aaG
  } else {
    Prot4<-c(Prot4, codon)
  }
  
}

Prot4
Mass4
