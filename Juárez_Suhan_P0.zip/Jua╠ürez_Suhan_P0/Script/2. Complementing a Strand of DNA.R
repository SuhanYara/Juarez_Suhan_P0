####################################
###### 2. Complementing a Strand of DNA ####
####################################

#Ejercicio a resolver:
#Ya que es RNA, debemos primero pasarlo a ADN, la diferencia es cambiar la U por T

######NOTA ####

###ES NECESARIO EJECTURA SECCIÓN 1 DEL EJERCICIO 1####
#SINO, EJECUTAR LO SIGUIENTE:
Secuencias1<-readRNAStringSet("Raw Data/first (1).fasta")
Secuencias1
###################################################################


#Un problema para esto es la clase de datos que se trabajan, si lo hacemos sobre este usando comandos de paqueteria, no sale
#Entonces cambiaremos la información
Secuencias1
class(Secuencias1)

#SECCIÓN 1####
##En  matriz, cada secuencia, después lo pasamos a Vector
Seq0<-as.matrix(Secuencias1["secuencia0"]) 
Seq0<-as.vector(Seq0)
Seq0

Seq1<-as.matrix(Secuencias1["secuencia1"]) 
Seq1<-as.vector(Seq1)
Seq1

Seq2<-as.matrix(Secuencias1["secuencia2"]) 
Seq2<-as.vector(Seq2)
Seq2

Seq3<-as.matrix(Secuencias1["secuencia3"]) 
Seq3<-as.vector(Seq3)
Seq3

Seq4<-as.matrix(Secuencias1["secuencia4"]) 
Seq4<-as.vector(Seq4)
Seq4

#SECCIÓN 2####
#Ya que tenemos las secuencias, usaremos el siguiente programa para pasarlo a ADN, donde se sustituirá U por T
#Esto en cada pequeña secuencia

DNAs0<-c()
for (i in Seq0) {
  if (i == "A") {
    DNAs0<-c(DNAs0,"A")
  } else if (i == "C") {
    DNAs0<-c(DNAs0,"C")
  } else if (i == "G") {
    DNAs0<-c(DNAs0,"G")
  } else {
    DNAs0<-c(DNAs0,"T")
  } 
  
}

DNAs0 #Se podrá ver la secuencia

DNAs1<-c()
for (i in Seq1) {
  if (i == "A") {
    DNAs1<-c(DNAs1,"A")
  } else if (i == "C") {
    DNAs1<-c(DNAs1,"C")
  } else if (i == "G") {
    DNAs1<-c(DNAs1,"G")
  } else {
    DNAs1<-c(DNAs1,"T")
  } 
  
}

DNAs1

DNAs2<-c()
for (i in Seq2) {
  if (i == "A") {
    DNAs2<-c(DNAs2,"A")
  } else if (i == "C") {
    DNAs2<-c(DNAs2,"C")
  } else if (i == "G") {
    DNAs2<-c(DNAs2,"G")
  } else {
    DNAs2<-c(DNAs2,"T")
  } 
  
}

DNAs2

DNAs3<-c()
for (i in Seq3) {
  if (i == "A") {
    DNAs3<-c(DNAs3,"A")
  } else if (i == "C") {
    DNAs3<-c(DNAs3,"C")
  } else if (i == "G") {
    DNAs3<-c(DNAs3,"G")
  } else {
    DNAs3<-c(DNAs3,"T")
  } 
  
}

DNAs3


DNAs4<-c()
for (i in Seq4) {
  if (i == "A") {
    DNAs4<-c(DNAs4,"A")
  } else if (i == "C") {
    DNAs4<-c(DNAs4,"C")
  } else if (i == "G") {
    DNAs4<-c(DNAs4,"G")
  } else {
    DNAs4<-c(DNAs4,"T")
  } 
  
}

DNAs4

#SECCIÓN 3####
##Ya tenemos las cadenas de ADN, ahora podemos usar los mismos programas, Sólo sustituyendo G-C y T-A.

ComplemDNAs0<-c()
for (i in DNAs0) {
  if (i == "A") {
    ComplemDNAs0<-c(ComplemDNAs0,"T") 
  } else if (i == "T") {
    ComplemDNAs0<-c(ComplemDNAs0,"A")
  } else if (i == "G") {
    ComplemDNAs0<-c(ComplemDNAs0,"C")
  } else {
    ComplemDNAs0<-c(ComplemDNAs0,"G")
  } 
  
}

ComplemDNAs1<-c()
for (i in DNAs1) {
  if (i == "A") {
    ComplemDNAs1<-c(ComplemDNAs1,"T")
  } else if (i == "T") {
    ComplemDNAs1<-c(ComplemDNAs1,"A")
  } else if (i == "G") {
    ComplemDNAs1<-c(ComplemDNAs1,"C")
  } else {
    ComplemDNAs1<-c(ComplemDNAs1,"G")
  } 
  
}

ComplemDNAs2<-c()
for (i in DNAs2) {
  if (i == "A") {
    ComplemDNAs2<-c(ComplemDNAs2,"T")
  } else if (i == "T") {
    ComplemDNAs2<-c(ComplemDNAs2,"A")
  } else if (i == "G") {
    ComplemDNAs2<-c(ComplemDNAs2,"C")
  } else {
    ComplemDNAs2<-c(ComplemDNAs2,"G")
  } 
  
}

ComplemDNAs3<-c()
for (i in DNAs3) {
  if (i == "A") {
    ComplemDNAs3<-c(ComplemDNAs3,"T")
  } else if (i == "T") {
    ComplemDNAs3<-c(ComplemDNAs3,"A")
  } else if (i == "G") {
    ComplemDNAs3<-c(ComplemDNAs3,"C")
  } else {
    ComplemDNAs3<-c(ComplemDNAs3,"G")
  } 
  
}

ComplemDNAs4<-c()
for (i in DNAs4) {
  if (i == "A") {
    ComplemDNAs4<-c(ComplemDNAs4,"T")
  } else if (i == "T") {
    ComplemDNAs4<-c(ComplemDNAs4,"A")
  } else if (i == "G") {
    ComplemDNAs4<-c(ComplemDNAs4,"C")
  } else {
    ComplemDNAs4<-c(ComplemDNAs4,"G")
  } 
  
}

##Visualizamos las cadenas complementarias
ComplemDNAs0
ComplemDNAs1
ComplemDNAs2
ComplemDNAs3
ComplemDNAs4

