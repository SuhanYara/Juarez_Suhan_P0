####################################
###### 4. Computing GC Content  ####
####################################
#Calcular contenido de GC en una secuencia

######NOTA####

###DEBE EJECUTARSE TODO EL EJERCICIO 3 PARA CONTINUAR CON ESTE EJERCICIO
############################################################################

GCseq0<-((Gseq0+Cseq0)/length(Seq0)) * 100
GCseq0

GCseq1<-((Gseq1+Cseq1)/length(Seq1)) * 100
GCseq1

GCseq2<-((Gseq2+Cseq2)/length(Seq2)) * 100
GCseq2

GCseq3<-((Gseq3+Cseq3)/length(Seq3)) * 100
GCseq3

GCseq4<-((Gseq4+Cseq4)/length(Seq4)) * 100
GCseq0
