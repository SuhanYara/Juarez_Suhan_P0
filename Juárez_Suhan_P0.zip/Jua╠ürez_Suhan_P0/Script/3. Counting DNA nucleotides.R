####################################
###### 3. Counting DNA nucleotides ####
####################################

#Ejercicio a resolver:
#Calcular contenido de cada nucleótido en una secuencia

######NOTA####

###DEBE EJECUTARSE SECCIÓN 1 DEL EJERCICIO 1 y SECCIÓN 1 DEL EJERCICIO 2, 
############################################################################

#SECCIÓN 1####
###Ahora, para resolver el problema primero creamos vectores vacíos decada para cada nucleótido en cada secuencia
Aseq0<-0
Cseq0<-0
Gseq0<-0
Tseq0<-0

for (i in DNAs0) {
  if (i == "A") {
    Aseq0<-Aseq0 +1 
  } else if (i == "T") {
    Tseq0<-Tseq0 +1
  } else if (i == "G") {
    Gseq0<-Gseq0+1
  } else {
    Tseq0<-Tseq0+1
  } 
  
}

Aseq0
Cseq0
Gseq0
Tseq0


#Lo podemos anidar en un vector , por ejemplo:

FrecBasesSec0<-c(Aseq0,Cseq0,Gseq0,Tseq0)
FrecBasesSec0

Bases<-c("A","C","G","T")
names(FrecBasesSec0)<-Bases
FrecBasesSec0

#Segunda secuencia

Aseq1<-0
Cseq1<-0
Gseq1<-0
Tseq1<-0

for (i in DNAs1) {
  if (i == "A") {
    Aseq1<-Aseq1 +1 
  } else if (i == "T") {
    Tseq1<-Tseq1 +1
  } else if (i == "G") {
    Gseq1<-Gseq1+1
  } else {
    Tseq1<-Tseq1+1
  } 
  
}

Aseq1
Cseq1
Gseq1
Tseq1

FrecBasesSec1<-c(Aseq1,Cseq1,Gseq1,Tseq1)
FrecBasesSec1
Bases<-c("A","C","G","T")
names(FrecBasesSec1)<-Bases

#Tercera secuencia

Aseq2<-0
Cseq2<-0
Gseq2<-0
Tseq2<-0

for (i in DNAs2) {
  if (i == "A") {
    Aseq2<-Aseq2 +1 
  } else if (i == "T") {
    Tseq2<-Tseq2 +1
  } else if (i == "G") {
    Gseq2<-Gseq2+1
  } else {
    Tseq2<-Tseq2+1
  } 
  
}

Aseq2
Cseq2
Gseq2
Tseq2

FrecBasesSec2<-c(Aseq2,Cseq2,Gseq2,Tseq2)
FrecBasesSec2
Bases<-c("A","C","G","T")
names(FrecBasesSec2)<-Bases


#Cuarta secuencia

Aseq3<-0
Cseq3<-0
Gseq3<-0
Tseq3<-0

for (i in DNAs3) {
  if (i == "A") {
    Aseq3<-Aseq3 +1 
  } else if (i == "T") {
    Tseq3<-Tseq3 +1
  } else if (i == "G") {
    Gseq3<-Gseq3+1
  } else {
    Tseq3<-Tseq3+1
  } 
  
}

Aseq3
Cseq3
Gseq3
Tseq3

FrecBasesSec3<-c(Aseq3,Cseq3,Gseq3,Tseq3)
FrecBasesSec3
Bases<-c("A","C","G","T")
names(FrecBasesSec3)<-Bases

#Quinta secuencia

Aseq4<-0
Cseq4<-0
Gseq4<-0
Tseq4<-0

for (i in DNAs4) {
  if (i == "A") {
    Aseq4<-Aseq4 +1 
  } else if (i == "T") {
    Tseq4<-Tseq4 +1
  } else if (i == "G") {
    Gseq4<-Gseq4+1
  } else {
    Tseq4<-Tseq4+1
  } 
  
}

Aseq4
Cseq4
Gseq4
Tseq4

FrecBasesSec4<-c(Aseq4,Cseq4,Gseq4,Tseq4)
FrecBasesSec4
Bases<-c("A","C","G","T")
names(FrecBasesSec4)<-Bases

####Aquí visualizamos todas laas frecuencias de nucleótidos
FrecBasesSec0
FrecBasesSec1
FrecBasesSec2
FrecBasesSec3
FrecBasesSec4

